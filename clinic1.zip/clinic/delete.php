<?php
$conn = new mysqli("localhost", "root", "", "clinic_db");

$id = $_GET['id'];

$sql = "DELETE FROM appointments WHERE id=$id";

$conn->query($sql);

header("Location: view_appointments.php");
?>