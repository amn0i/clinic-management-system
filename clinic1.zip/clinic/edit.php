<?php
$conn = new mysqli("localhost", "root", "", "clinic_db");

$id = $_GET['id'];

$result = $conn->query("SELECT * FROM appointments WHERE id=$id");
$row = $result->fetch_assoc();
?>

<form method="POST">
<input type="text" name="name" value="<?php echo $row['patient_name']; ?>"><br>
<input type="text" name="doctor" value="<?php echo $row['doctor']; ?>"><br>
<input type="date" name="date" value="<?php echo $row['appointment_date']; ?>"><br>
<input type="submit" value="Update">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $doctor = $_POST['doctor'];
    $date = $_POST['date'];

    $conn->query("UPDATE appointments 
    SET patient_name='$name', doctor='$doctor', appointment_date='$date'
    WHERE id=$id");

    header("Location: view_appointments.php");
}
?>