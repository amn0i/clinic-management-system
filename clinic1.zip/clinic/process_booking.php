<?php
$conn = new mysqli("localhost", "root", "", "clinic_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$patientName = $_POST['patientName'];
$doctor = $_POST['doctor'];
$appDate = $_POST['appDate'];

$sql = "INSERT INTO appointments (patient_name, doctor, appointment_date)
VALUES ('$patientName', '$doctor', '$appDate')";

if ($conn->query($sql) === TRUE) {
    echo "Appointment booked successfully!<br><br>";
    echo "<a href='view_appointments.php'>View Appointments</a>";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>