document.getElementById('appointmentForm').addEventListener('submit', function(event) {
    let errors = [];
    const patientName = document.getElementById('patientName').value.trim();
    const doctor = document.getElementById('doctor').value;
    const appDate = document.getElementById('appDate').value;

    if (patientName === "") {
        errors.push("- Patient Name is required.");
    }
    if (doctor === "") {
        errors.push("- Please select a Doctor.");
    }
    if (appDate === "") {
        errors.push("- Please select a Date.");
    }

    if (errors.length > 0) {
        event.preventDefault(); // يمنع الانتقال لصفحة PHP إذا وجد خطأ
        alert("Please correct the following errors:\n" + errors.join("\n"));
    }
});