<?php
$conn = new mysqli("localhost", "root", "", "clinic_db");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM appointments";
$result = $conn->query($sql);

echo "<h2>Appointments List</h2>";

if ($result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Patient Name</th>
                <th>Doctor</th>
                <th>Date</th>
            </tr>";
    
    while($row = $result->fetch_assoc()) {
    echo "<tr>
    <td>".$row["id"]."</td>
    <td>".$row["patient_name"]."</td>
    <td>".$row["doctor"]."</td>
    <td>".$row["appointment_date"]."</td>
    <td>
        <a href='delete.php?id=".$row["id"]."'>Delete</a> |
        <a href='edit.php?id=".$row["id"]."'>Edit</a>
    </td>
    </tr>";
}
    echo "</table>";
} else {
    echo "No appointments found";
}

$conn->close();
?>
